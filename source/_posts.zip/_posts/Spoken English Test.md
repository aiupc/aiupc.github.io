---
title: Spoken English Test
author: 孙鹏程
avatar: 
authorLink: 
authorAbout: 
authorDesc: 
categories: 班级活动
comments: true
tags: []
id: '1125'
date: 2021-06-06 17:52:22
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/aiupc/drawingbed/img/20220117233902.png
---

# Just This?

In my opinion, the test is not too easy for us. But we can do it.

Before the test, I hadn't prapare enough, so I feel quite \*fuck\* when I saw the twenty 话题s, and I 不愧是 I. I just prepared four or five topic, and 没有考到. I don't know our 卷king prepared how, because I'm afraid to wenwentamen.

So it's really hard to go. But when I enter the 考场, and saw the topic, I feel much better. Education promise employment? I don't know but I'm good at 瞎编. So I passed the first stage easily. The only problem is that I don't know what I've said.

\==But, that's GREAT!==

I believe my group member don't konw what i say, too. So they won't ask me in the next disussion. I guess.

\==what a little clever ghost I am!==

However, to my surprise, they asked me again, I don't konw what to say because I don't know what he said. So I push the 烫手山芋 to Su Weijing and Wang Shilong. The steps are following:

1.  I know Wang may prepared better so I dicide to 控他 with a question. And let he enjoy 经验 by himself.
2.  Then I find Su is nervious, so i 打断施法 with fuzhusanlain:"Yes!","I know!","I'm agree with you!"
3.  About Zhang, we peace 发育.

After these steps, I feel much better and more 有信心. From this side, I think the test is much easier than the king-honor game, and 不管 the result is how，all of us fell happy during the 过程.

**AND now,I want to say, thank you very much for not asking me again and again.** PS: All the things upon is 扯的, I won't take any responsibility. Grass, a kind of plant.

Yours

Pengcheng