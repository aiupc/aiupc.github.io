---
title: 本研AI合唱比赛第二次排练正在进行
author: 孙百乐
avatar: 
authorLink: 
authorAbout: 
authorDesc: 
categories: 班级活动
comments: true
tags: []
id: '293'
date: 2020-10-27 12:36:12
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/aiupc/drawingbed/img/合唱比赛-300x225.jpg
---

今天本研一体化班（人工智能类）全班同学又齐聚活动室练习《相信我们会创造奇迹》和《北京石油学院学生之歌》，全体同学均准时到达训练场。

* * *

在刘逸霄同学的主持下，演练紧锣密鼓地进行，在演练中出现了以下问题： 1. 全体同学（包括两名领唱）虽然都能记住歌词，但是偶尔会弄混角色。两名领唱的唱法也不熟练，节奏把握的不好。 2. 第二首校歌确实他妈难唱，不好搞。 3. 可能同学们还没有完全记熟歌词，有些同学在练习时需要时常看手机，害怕唱错，声音比较小，这样是开不了军舰的。

* * *

不过还好，以上问题都是可以通过练习来解决的，总体上来说，这次排练的效果比上次好很多，大家继续加油，心理上看淡比赛，态度上认真对待！ 投稿人：孙百乐

![](https://cdn.jsdelivr.net/gh/aiupc/drawingbed/img/合唱比赛-300x225.jpg)